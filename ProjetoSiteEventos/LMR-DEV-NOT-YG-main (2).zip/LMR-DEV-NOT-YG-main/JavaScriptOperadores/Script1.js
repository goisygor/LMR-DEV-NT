// Script de valor inteiro
let Numero1;
let Numero2;
let Resposta;

Numero1 = prompt('Digite um valor: ' , 'Digite um Número');
Numero1 = prompt('Digite outro valor: ' , 'Digite um Número');
// realiza a soma de dois n° inteiros
Resposta = parseInt(Numero1) + parseInt(Numero2);

document.write('O resultado da Soma é ', Resposta);
