let NOME;
NOME = prompt('Entre com seu nome:','Digite-o aqui');
document.write('Oi'+ NOME + ' esteja a vontade.');