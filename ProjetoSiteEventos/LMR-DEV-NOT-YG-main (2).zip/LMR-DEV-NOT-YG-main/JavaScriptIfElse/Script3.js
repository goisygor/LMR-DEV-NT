let diaSemana;

diaSemana = prompt ("Informe o número" , "1-7");

if(diaSemana==1){ 
    document.write ("Domingo");
}else if(diaSemana==2){
    document.write("Segunda-Feira");
}else if(diaSemana==3){
    document.write("Terça-Feira");
}else if(diaSemana==4){
    document.write("Quarta-Feira");
}else if(diaSemana==5){
    document.write("Quinta-Feira");
}else if(diaSemana==6){
    document.write("Sexta-Feira");
}if(diaSemana==7){
    document.write("Sabádo");
}else{
    document.write("Digite um N° Válido");
}
