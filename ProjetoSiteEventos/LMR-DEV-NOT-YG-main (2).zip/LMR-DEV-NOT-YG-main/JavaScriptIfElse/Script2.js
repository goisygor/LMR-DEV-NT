let diaSemana;

diaSemana = prompt ("Informe o número" , "1-7");

if(diaSemana==1){ document.write ("Domingo");}
if(diaSemana==2){document.write("Segunda-Feira");}
if(diaSemana==3){document.write("Terça-Feira");}
if(diaSemana==4){document.write("Quarta-Feira");}
if(diaSemana==5){document.write("Quinta-Feira");}
if(diaSemana==6){document.write("Sexta-Feira");}
if(diaSemana==7){document.write("Sabádo");}
