let idade;
idade = prompt("Informa a Sua Idade" , "Digite Aqui");
if(idade >= 18){
    document.write ("Você pode Dirigir");
}else{
    document.write('Você não pode Dirigir');
}